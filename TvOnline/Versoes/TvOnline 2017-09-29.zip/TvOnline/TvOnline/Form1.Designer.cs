﻿using System.Windows.Forms;

namespace TvOnline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.PictureBox picControle;
            System.Windows.Forms.Label label2;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnChMais = new System.Windows.Forms.Button();
            this.btnChMenos = new System.Windows.Forms.Button();
            this.btnVolMais = new System.Windows.Forms.Button();
            this.btnLista = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.lblCh = new System.Windows.Forms.Label();
            this.btnPower = new System.Windows.Forms.Button();
            this.btnSobre = new System.Windows.Forms.Button();
            this.chListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnVolMenos = new System.Windows.Forms.Button();
            this.btnMute = new System.Windows.Forms.Button();
            this.TVpic = new System.Windows.Forms.PictureBox();
            this.chuviscoPic = new System.Windows.Forms.PictureBox();
            this.axVLC = new AxAXVLC.AxVLCPlugin2();
            this.lblVol = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.picLogo = new System.Windows.Forms.PictureBox();
            picControle = new System.Windows.Forms.PictureBox();
            label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(picControle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TVpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chuviscoPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axVLC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // picControle
            // 
            picControle.Image = global::TvOnline.Properties.Resources.controle_remoto;
            picControle.Location = new System.Drawing.Point(9, 95);
            picControle.Name = "picControle";
            picControle.Size = new System.Drawing.Size(117, 356);
            picControle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picControle.TabIndex = 8;
            picControle.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.Location = new System.Drawing.Point(27, 460);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(50, 15);
            label2.TabIndex = 12;
            label2.Text = "Volume:";
            // 
            // btnChMais
            // 
            this.btnChMais.BackColor = System.Drawing.SystemColors.Control;
            this.btnChMais.FlatAppearance.BorderSize = 0;
            this.btnChMais.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChMais.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChMais.Location = new System.Drawing.Point(73, 177);
            this.btnChMais.Name = "btnChMais";
            this.btnChMais.Size = new System.Drawing.Size(38, 52);
            this.btnChMais.TabIndex = 3;
            this.btnChMais.Text = "CH +";
            this.btnChMais.UseVisualStyleBackColor = false;
            this.btnChMais.Click += new System.EventHandler(this.chMudar);
            // 
            // btnChMenos
            // 
            this.btnChMenos.BackColor = System.Drawing.SystemColors.Control;
            this.btnChMenos.FlatAppearance.BorderSize = 0;
            this.btnChMenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChMenos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChMenos.Location = new System.Drawing.Point(73, 232);
            this.btnChMenos.Name = "btnChMenos";
            this.btnChMenos.Size = new System.Drawing.Size(38, 52);
            this.btnChMenos.TabIndex = 4;
            this.btnChMenos.Text = "CH  -";
            this.btnChMenos.UseVisualStyleBackColor = false;
            this.btnChMenos.Click += new System.EventHandler(this.chMudar);
            // 
            // btnVolMais
            // 
            this.btnVolMais.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMais.FlatAppearance.BorderSize = 0;
            this.btnVolMais.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolMais.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolMais.Location = new System.Drawing.Point(25, 177);
            this.btnVolMais.Name = "btnVolMais";
            this.btnVolMais.Size = new System.Drawing.Size(38, 52);
            this.btnVolMais.TabIndex = 6;
            this.btnVolMais.Text = "VOL +";
            this.btnVolMais.UseVisualStyleBackColor = false;
            this.btnVolMais.Click += new System.EventHandler(this.volumeHandler);
            // 
            // btnLista
            // 
            this.btnLista.BackColor = System.Drawing.Color.LimeGreen;
            this.btnLista.FlatAppearance.BorderSize = 0;
            this.btnLista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLista.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLista.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnLista.Location = new System.Drawing.Point(23, 343);
            this.btnLista.Name = "btnLista";
            this.btnLista.Size = new System.Drawing.Size(90, 23);
            this.btnLista.TabIndex = 2;
            this.btnLista.Text = "Channel List";
            this.btnLista.UseVisualStyleBackColor = false;
            this.btnLista.Click += new System.EventHandler(this.listarCanais);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnMenu.Location = new System.Drawing.Point(23, 372);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(90, 23);
            this.btnMenu.TabIndex = 5;
            this.btnMenu.Text = "Menu";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // lblCh
            // 
            this.lblCh.AutoSize = true;
            this.lblCh.BackColor = System.Drawing.Color.Black;
            this.lblCh.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCh.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblCh.Location = new System.Drawing.Point(245, 75);
            this.lblCh.MaximumSize = new System.Drawing.Size(500, 0);
            this.lblCh.Name = "lblCh";
            this.lblCh.Padding = new System.Windows.Forms.Padding(3);
            this.lblCh.Size = new System.Drawing.Size(37, 19);
            this.lblCh.TabIndex = 0;
            this.lblCh.Text = "CH 3";
            // 
            // btnPower
            // 
            this.btnPower.BackColor = System.Drawing.Color.Red;
            this.btnPower.FlatAppearance.BorderSize = 0;
            this.btnPower.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPower.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPower.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnPower.Location = new System.Drawing.Point(75, 109);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(38, 38);
            this.btnPower.TabIndex = 1;
            this.btnPower.Text = "Liga";
            this.btnPower.UseVisualStyleBackColor = false;
            this.btnPower.Click += new System.EventHandler(this.ligarDesligar);
            // 
            // btnSobre
            // 
            this.btnSobre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSobre.Location = new System.Drawing.Point(9, 490);
            this.btnSobre.Name = "btnSobre";
            this.btnSobre.Size = new System.Drawing.Size(117, 23);
            this.btnSobre.TabIndex = 10;
            this.btnSobre.Text = "Sobre";
            this.btnSobre.UseVisualStyleBackColor = true;
            this.btnSobre.Click += new System.EventHandler(this.btnSobre_Click);
            // 
            // chListView
            // 
            this.chListView.BackColor = System.Drawing.SystemColors.MenuBar;
            this.chListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.chListView.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chListView.ForeColor = System.Drawing.Color.MidnightBlue;
            this.chListView.FullRowSelect = true;
            this.chListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.chListView.HideSelection = false;
            this.chListView.Location = new System.Drawing.Point(247, 149);
            this.chListView.Name = "chListView";
            this.chListView.Size = new System.Drawing.Size(490, 270);
            this.chListView.TabIndex = 0;
            this.chListView.TabStop = false;
            this.chListView.UseCompatibleStateImageBehavior = false;
            this.chListView.View = System.Windows.Forms.View.Details;
            this.chListView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.chListView_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Tag = "";
            this.columnHeader1.Text = "Ch";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nome";
            this.columnHeader2.Width = 179;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Grupo";
            this.columnHeader3.Width = 127;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Pais";
            this.columnHeader4.Width = 132;
            // 
            // btnVolMenos
            // 
            this.btnVolMenos.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMenos.FlatAppearance.BorderSize = 0;
            this.btnVolMenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolMenos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolMenos.Location = new System.Drawing.Point(25, 232);
            this.btnVolMenos.Name = "btnVolMenos";
            this.btnVolMenos.Size = new System.Drawing.Size(38, 52);
            this.btnVolMenos.TabIndex = 7;
            this.btnVolMenos.Text = "VOL -";
            this.btnVolMenos.UseVisualStyleBackColor = false;
            this.btnVolMenos.Click += new System.EventHandler(this.volumeHandler);
            // 
            // btnMute
            // 
            this.btnMute.BackColor = System.Drawing.SystemColors.Control;
            this.btnMute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMute.ForeColor = System.Drawing.Color.White;
            this.btnMute.Image = global::TvOnline.Properties.Resources.mute;
            this.btnMute.Location = new System.Drawing.Point(52, 296);
            this.btnMute.Margin = new System.Windows.Forms.Padding(0);
            this.btnMute.Name = "btnMute";
            this.btnMute.Size = new System.Drawing.Size(28, 28);
            this.btnMute.TabIndex = 8;
            this.btnMute.Tag = "0";
            this.btnMute.UseVisualStyleBackColor = false;
            this.btnMute.Click += new System.EventHandler(this.volumeHandler);
            // 
            // TVpic
            // 
            this.TVpic.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.TVpic.BackColor = System.Drawing.Color.Black;
            this.TVpic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TVpic.Image = ((System.Drawing.Image)(resources.GetObject("TVpic.Image")));
            this.TVpic.InitialImage = ((System.Drawing.Image)(resources.GetObject("TVpic.InitialImage")));
            this.TVpic.Location = new System.Drawing.Point(136, -3);
            this.TVpic.Name = "TVpic";
            this.TVpic.Size = new System.Drawing.Size(850, 524);
            this.TVpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TVpic.TabIndex = 0;
            this.TVpic.TabStop = false;
            // 
            // chuviscoPic
            // 
            this.chuviscoPic.BackColor = System.Drawing.SystemColors.Window;
            this.chuviscoPic.Image = global::TvOnline.Properties.Resources.tvstatic;
            this.chuviscoPic.InitialImage = global::TvOnline.Properties.Resources.tvstatic;
            this.chuviscoPic.Location = new System.Drawing.Point(216, 68);
            this.chuviscoPic.Name = "chuviscoPic";
            this.chuviscoPic.Size = new System.Drawing.Size(559, 372);
            this.chuviscoPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.chuviscoPic.TabIndex = 3;
            this.chuviscoPic.TabStop = false;
            // 
            // axVLC
            // 
            this.axVLC.Enabled = true;
            this.axVLC.Location = new System.Drawing.Point(215, 68);
            this.axVLC.Name = "axVLC";
            this.axVLC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axVLC.OcxState")));
            this.axVLC.Size = new System.Drawing.Size(560, 372);
            this.axVLC.TabIndex = 0;
            this.axVLC.TabStop = false;
            // 
            // lblVol
            // 
            this.lblVol.AutoSize = true;
            this.lblVol.BackColor = System.Drawing.Color.White;
            this.lblVol.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVol.ForeColor = System.Drawing.Color.Black;
            this.lblVol.Location = new System.Drawing.Point(83, 460);
            this.lblVol.Name = "lblVol";
            this.lblVol.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblVol.Size = new System.Drawing.Size(23, 15);
            this.lblVol.TabIndex = 11;
            this.lblVol.Text = "vol";
            this.lblVol.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::TvOnline.Properties.Resources.RetroTvPNG;
            this.picLogo.Location = new System.Drawing.Point(23, 12);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(90, 70);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabIndex = 13;
            this.picLogo.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 521);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(label2);
            this.Controls.Add(this.lblVol);
            this.Controls.Add(this.btnMute);
            this.Controls.Add(this.chListView);
            this.Controls.Add(this.btnSobre);
            this.Controls.Add(this.lblCh);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnLista);
            this.Controls.Add(this.btnVolMenos);
            this.Controls.Add(this.btnChMenos);
            this.Controls.Add(this.btnVolMais);
            this.Controls.Add(this.btnPower);
            this.Controls.Add(this.btnChMais);
            this.Controls.Add(picControle);
            this.Controls.Add(this.TVpic);
            this.Controls.Add(this.axVLC);
            this.Controls.Add(this.chuviscoPic);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TV Online";
            this.TransparencyKey = System.Drawing.Color.Azure;
            ((System.ComponentModel.ISupportInitialize)(picControle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TVpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chuviscoPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axVLC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnChMais;
        private System.Windows.Forms.PictureBox chuviscoPic;
        private System.Windows.Forms.Button btnChMenos;
        private System.Windows.Forms.Button btnVolMais;
        private System.Windows.Forms.Button btnVolMenos;
        private System.Windows.Forms.Button btnPower;
        private System.Windows.Forms.Button btnLista;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Label lblCh;
        private System.Windows.Forms.Button btnSobre;
        private System.Windows.Forms.ListView chListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnMute;
        protected AxAXVLC.AxVLCPlugin2 axVLC;
        private System.Windows.Forms.Label lblVol;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.PictureBox TVpic;

    }
}

