﻿namespace TvOnline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.PictureBox picControle;
            System.Windows.Forms.Label label2;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnChMais = new System.Windows.Forms.Button();
            this.btnChMenos = new System.Windows.Forms.Button();
            this.btnVolMais = new System.Windows.Forms.Button();
            this.btnLista = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.lblCh = new System.Windows.Forms.Label();
            this.btnPower = new System.Windows.Forms.Button();
            this.btnSobre = new System.Windows.Forms.Button();
            this.chListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnVolMenos = new System.Windows.Forms.Button();
            this.btnMute = new System.Windows.Forms.Button();
            this.TVpic = new System.Windows.Forms.PictureBox();
            this.chuviscoPic = new System.Windows.Forms.PictureBox();
            this.axVLC = new AxAXVLC.AxVLCPlugin2();
            this.lblVol = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            picControle = new System.Windows.Forms.PictureBox();
            label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(picControle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TVpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chuviscoPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axVLC)).BeginInit();
            this.SuspendLayout();
            // 
            // picControle
            // 
            picControle.Image = global::TvOnline.Properties.Resources.controle_remoto;
            picControle.Location = new System.Drawing.Point(9, 12);
            picControle.Name = "picControle";
            picControle.Size = new System.Drawing.Size(117, 371);
            picControle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picControle.TabIndex = 8;
            picControle.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.Location = new System.Drawing.Point(15, 395);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(50, 15);
            label2.TabIndex = 12;
            label2.Text = "Volume:";
            // 
            // btnChMais
            // 
            this.btnChMais.BackColor = System.Drawing.SystemColors.Control;
            this.btnChMais.FlatAppearance.BorderSize = 0;
            this.btnChMais.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChMais.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChMais.Location = new System.Drawing.Point(73, 103);
            this.btnChMais.Name = "btnChMais";
            this.btnChMais.Size = new System.Drawing.Size(38, 52);
            this.btnChMais.TabIndex = 3;
            this.btnChMais.Text = "CH +";
            this.btnChMais.UseVisualStyleBackColor = false;
            this.btnChMais.Click += new System.EventHandler(this.chMudar);
            // 
            // btnChMenos
            // 
            this.btnChMenos.BackColor = System.Drawing.SystemColors.Control;
            this.btnChMenos.FlatAppearance.BorderSize = 0;
            this.btnChMenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChMenos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChMenos.Location = new System.Drawing.Point(73, 158);
            this.btnChMenos.Name = "btnChMenos";
            this.btnChMenos.Size = new System.Drawing.Size(38, 52);
            this.btnChMenos.TabIndex = 4;
            this.btnChMenos.Text = "CH  -";
            this.btnChMenos.UseVisualStyleBackColor = false;
            this.btnChMenos.Click += new System.EventHandler(this.chMudar);
            // 
            // btnVolMais
            // 
            this.btnVolMais.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMais.FlatAppearance.BorderSize = 0;
            this.btnVolMais.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolMais.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolMais.Location = new System.Drawing.Point(25, 103);
            this.btnVolMais.Name = "btnVolMais";
            this.btnVolMais.Size = new System.Drawing.Size(38, 52);
            this.btnVolMais.TabIndex = 6;
            this.btnVolMais.Text = "VOL +";
            this.btnVolMais.UseVisualStyleBackColor = false;
            this.btnVolMais.Click += new System.EventHandler(this.volumeHandler);
            // 
            // btnLista
            // 
            this.btnLista.BackColor = System.Drawing.Color.LimeGreen;
            this.btnLista.FlatAppearance.BorderSize = 0;
            this.btnLista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLista.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLista.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnLista.Location = new System.Drawing.Point(23, 269);
            this.btnLista.Name = "btnLista";
            this.btnLista.Size = new System.Drawing.Size(90, 23);
            this.btnLista.TabIndex = 2;
            this.btnLista.Text = "Channel List";
            this.btnLista.UseVisualStyleBackColor = false;
            this.btnLista.Click += new System.EventHandler(this.listarCanais);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnMenu.Location = new System.Drawing.Point(23, 298);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(90, 23);
            this.btnMenu.TabIndex = 5;
            this.btnMenu.Text = "Menu";
            this.btnMenu.UseVisualStyleBackColor = false;
            // 
            // lblCh
            // 
            this.lblCh.AutoSize = true;
            this.lblCh.BackColor = System.Drawing.Color.Black;
            this.lblCh.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCh.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblCh.Location = new System.Drawing.Point(245, 75);
            this.lblCh.MaximumSize = new System.Drawing.Size(500, 0);
            this.lblCh.Name = "lblCh";
            this.lblCh.Padding = new System.Windows.Forms.Padding(3);
            this.lblCh.Size = new System.Drawing.Size(37, 19);
            this.lblCh.TabIndex = 0;
            this.lblCh.Text = "CH 3";
            // 
            // btnPower
            // 
            this.btnPower.BackColor = System.Drawing.Color.Red;
            this.btnPower.FlatAppearance.BorderSize = 0;
            this.btnPower.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPower.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPower.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnPower.Location = new System.Drawing.Point(75, 31);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(38, 38);
            this.btnPower.TabIndex = 1;
            this.btnPower.Text = "Liga";
            this.btnPower.UseVisualStyleBackColor = false;
            this.btnPower.Click += new System.EventHandler(this.ligarDesligar);
            // 
            // btnSobre
            // 
            this.btnSobre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSobre.Location = new System.Drawing.Point(9, 486);
            this.btnSobre.Name = "btnSobre";
            this.btnSobre.Size = new System.Drawing.Size(117, 23);
            this.btnSobre.TabIndex = 10;
            this.btnSobre.Text = "Sobre";
            this.btnSobre.UseVisualStyleBackColor = true;
            this.btnSobre.Click += new System.EventHandler(this.btnSobre_Click);
            // 
            // chListView
            // 
            this.chListView.BackColor = System.Drawing.SystemColors.MenuBar;
            this.chListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.chListView.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chListView.ForeColor = System.Drawing.Color.MidnightBlue;
            this.chListView.FullRowSelect = true;
            this.chListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.chListView.HideSelection = false;
            this.chListView.Location = new System.Drawing.Point(247, 149);
            this.chListView.Name = "chListView";
            this.chListView.Size = new System.Drawing.Size(490, 270);
            this.chListView.TabIndex = 0;
            this.chListView.TabStop = false;
            this.chListView.UseCompatibleStateImageBehavior = false;
            this.chListView.View = System.Windows.Forms.View.Details;
            this.chListView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.chListView_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Tag = "";
            this.columnHeader1.Text = "Ch";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Link";
            this.columnHeader2.Width = 440;
            // 
            // btnVolMenos
            // 
            this.btnVolMenos.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMenos.FlatAppearance.BorderSize = 0;
            this.btnVolMenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolMenos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolMenos.Location = new System.Drawing.Point(25, 158);
            this.btnVolMenos.Name = "btnVolMenos";
            this.btnVolMenos.Size = new System.Drawing.Size(38, 52);
            this.btnVolMenos.TabIndex = 7;
            this.btnVolMenos.Text = "VOL -";
            this.btnVolMenos.UseVisualStyleBackColor = false;
            this.btnVolMenos.Click += new System.EventHandler(this.volumeHandler);
            // 
            // btnMute
            // 
            this.btnMute.BackColor = System.Drawing.SystemColors.Control;
            this.btnMute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMute.ForeColor = System.Drawing.Color.White;
            this.btnMute.Image = global::TvOnline.Properties.Resources.mute1;
            this.btnMute.Location = new System.Drawing.Point(52, 222);
            this.btnMute.Margin = new System.Windows.Forms.Padding(0);
            this.btnMute.Name = "btnMute";
            this.btnMute.Size = new System.Drawing.Size(28, 28);
            this.btnMute.TabIndex = 8;
            this.btnMute.Tag = "0";
            this.btnMute.UseVisualStyleBackColor = false;
            this.btnMute.Click += new System.EventHandler(this.volumeHandler);
            // 
            // TVpic
            // 
            this.TVpic.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.TVpic.BackColor = System.Drawing.Color.Black;
            this.TVpic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TVpic.Image = ((System.Drawing.Image)(resources.GetObject("TVpic.Image")));
            this.TVpic.InitialImage = ((System.Drawing.Image)(resources.GetObject("TVpic.InitialImage")));
            this.TVpic.Location = new System.Drawing.Point(136, -3);
            this.TVpic.Name = "TVpic";
            this.TVpic.Size = new System.Drawing.Size(850, 524);
            this.TVpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TVpic.TabIndex = 0;
            this.TVpic.TabStop = false;
            // 
            // chuviscoPic
            // 
            this.chuviscoPic.BackColor = System.Drawing.SystemColors.Window;
            this.chuviscoPic.Image = global::TvOnline.Properties.Resources.tvstatic;
            this.chuviscoPic.InitialImage = global::TvOnline.Properties.Resources.tvstatic;
            this.chuviscoPic.Location = new System.Drawing.Point(216, 68);
            this.chuviscoPic.Name = "chuviscoPic";
            this.chuviscoPic.Size = new System.Drawing.Size(559, 372);
            this.chuviscoPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.chuviscoPic.TabIndex = 3;
            this.chuviscoPic.TabStop = false;
            // 
            // axVLC
            // 
            this.axVLC.Enabled = true;
            this.axVLC.Location = new System.Drawing.Point(215, 68);
            this.axVLC.Name = "axVLC";
            this.axVLC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axVLC.OcxState")));
            this.axVLC.Size = new System.Drawing.Size(560, 372);
            this.axVLC.TabIndex = 0;
            this.axVLC.TabStop = false;
            // 
            // lblVol
            // 
            this.lblVol.AutoSize = true;
            this.lblVol.BackColor = System.Drawing.Color.White;
            this.lblVol.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVol.ForeColor = System.Drawing.Color.Black;
            this.lblVol.Location = new System.Drawing.Point(71, 395);
            this.lblVol.Name = "lblVol";
            this.lblVol.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblVol.Size = new System.Drawing.Size(47, 15);
            this.lblVol.TabIndex = 11;
            this.lblVol.Text = "volume";
            this.lblVol.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipTitle = "Fullscreen";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 521);
            this.Controls.Add(label2);
            this.Controls.Add(this.lblVol);
            this.Controls.Add(this.btnMute);
            this.Controls.Add(this.chListView);
            this.Controls.Add(this.btnSobre);
            this.Controls.Add(this.lblCh);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnLista);
            this.Controls.Add(this.btnVolMenos);
            this.Controls.Add(this.btnChMenos);
            this.Controls.Add(this.btnVolMais);
            this.Controls.Add(this.btnPower);
            this.Controls.Add(this.btnChMais);
            this.Controls.Add(picControle);
            this.Controls.Add(this.TVpic);
            this.Controls.Add(this.axVLC);
            this.Controls.Add(this.chuviscoPic);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TV Online";
            this.TransparencyKey = System.Drawing.Color.Azure;
            ((System.ComponentModel.ISupportInitialize)(picControle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TVpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chuviscoPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axVLC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox TVpic;
        private System.Windows.Forms.Button btnChMais;
        private System.Windows.Forms.PictureBox chuviscoPic;
        private System.Windows.Forms.Button btnChMenos;
        private System.Windows.Forms.Button btnVolMais;
        private System.Windows.Forms.Button btnVolMenos;
        private System.Windows.Forms.Button btnPower;
        private System.Windows.Forms.Button btnLista;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Label lblCh;
        private System.Windows.Forms.Button btnSobre;
        private System.Windows.Forms.ListView chListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnMute;
        protected AxAXVLC.AxVLCPlugin2 axVLC;
        private System.Windows.Forms.Label lblVol;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

