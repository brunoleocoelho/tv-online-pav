using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using ShockwaveFlashObjects;
using System.Diagnostics;

namespace TvOnline  
{
    public partial class Form1 : Form
    {
        string []canal;
        int chIndex;
        bool ligado;
        bool listaOn;
        
        public Form1()
        {
            InitializeComponent();

            ligado = false;                         //controla se Tv lidada / desligada
            chIndex = 0;                            //indice do canal
            listaOn = false;                        //controla exibi��o da lista de canais
            chListView.SendToBack();                //lista de canais na tela
            lblCh.SendToBack();                     //label do canal na tela
            lblVol.Text = axVLC.volume.ToString();  //label que exibe o volume do audio

            //canais no array provis�rio
            //usaremos classe para BD SQLite e Canal
            canal = new string[15];
            canal[0] = "http://gbbrlive2.sambatech.com.br/liveevent/sbtabr_8fcdc5f0f8df8d4de56b22a2c6660470/livestream1/chunklist.m3u8"; //SBT HD
            canal[1] = "http://158.58.172.5:8081/look/sptv81/playlist.m3u8"; //GLOBO SP
            canal[2] = "http://200.189.113.201/hls/tve.m3u8"; //TV CULTURA
            canal[3] = "http://158.58.172.5:8081/look/band8/playlist.m3u8"; //BAND
            canal[4] = "http://api.new.livestream.com/accounts/16991778/events/6670101/live.m3u8"; //SESC TV
            canal[5] = "http://95.141.35.104:8081/look/cartoon8/playlist.m3u8"; //CARTOON NETWORK
            canal[6] = "http://stmv2.srvstm.com/cartoonr/cartoonr/playlist.m3u8"; //RETRO CARTOON
            canal[7] = "http://cmghlslive-i.akamaihd.net:80/hls/live/224710/WFOX/904k/prog.m3u8"; //FOX NEWS
            canal[8] = "http://158.58.172.5:8081/look/foxsports10/playlist.m3u8"; //FOX SPORTS
            canal[9] = "http://95.141.35.104:8081/look/sportv81/playlist.m3u8"; //SPORTV
        }

        /// <summary>
        /// Metodo da classe sobrescrito para fechar toda a aplica��o
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            this.Dispose();
            Application.Exit();
        }

        /// <summary>
        /// Liga ou desliga a TV
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ligarDesligar (object sender, EventArgs e)
        {
            if (!ligado)
            {
                btnPower.Text = "Desl";
                exibirCanal(canal[chIndex]);
                toolTip1.SetToolTip(TVpic, "Clique duplo sobre a tela para FULLSCREEN");
            }
            else
            {
                btnPower.Text = "Liga";
                this.Text = Properties.Resources.AppName + ": Desligado!";
                TVpic.BringToFront();
                listaOn = false;
                axVLC.playlist.stop();
            }
            ligado = !ligado;
        }

        /// <summary>
        /// Exibe e carrega o canal atrav�s do link, trazendo pra frente no layout
        /// </summary>
        /// <param name="channel">O canal que ser� carregado</param>
        private void exibirCanal (string channel)
        {
            axVLC.playlist.stop();
            try
            {
                if (channel != null)
                {
                    //enviando a lista para tr�s
                    listaOn = false;

                    axVLC.playlist.items.clear();
                    string absUri = new Uri(channel).AbsoluteUri.ToString();

                    //axVLC.MRL = channel;
                    axVLC.playlist.add(absUri);
                    axVLC.playlist.play();
                    axVLC.BringToFront();

                    lblCh.BringToFront();
                    //if (axVLC.playlist.isPlaying)
                    //else
                    //{
                    //    axVLC.playlist.stop();
                    //    chuviscoPic.BringToFront();
                    //}
                }
                else
                {
                    chuviscoPic.BringToFront();
                }

                rotularCanal(1, (chIndex + 1).ToString("000"), channel);
            }
            catch (Exception ex)
            {
                chuviscoPic.BringToFront();
                rotularCanal(2, (chIndex+1).ToString("000"), ex.Message);
            }
        }

        /// <summary>
        /// Rotula o canal na tela e a barra de titulo.
        /// Tipos: 1=Nome do Canal, 2=Fora do ar
        /// </summary>
        /// <param name="tipo"></param>
        /// <param name="channel"></param>
        /// <param name="rotulo"></param>
        private void rotularCanal(int tipo, string channel, string rotulo)
        {
            this.Text = Properties.Resources.AppName +" - Canal " + channel + ": " + rotulo;
            switch (tipo)
            {
                case 1: //Canal em exibi��o
                    lblCh.Text = "Canal " + channel +": "+ rotulo;
                    break;

                case 2: //"Fora do Ar" ou erro
                    lblCh.Text = "Canal "+ channel + ": Fora do ar! :-(";
                    break;

                default:
                    break;
            }
            lblCh.BringToFront();
        }

        /// <summary>
        /// Chamado pelo bot�o para mudar o canal em exibi��o
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chMudar(object sender, EventArgs e)
        {
            if (ligado) {
                var obj = new Control();
                if (sender.GetType().Name == "ListView")
                    obj = (ListView)sender;
                else if (sender.GetType().Name == "Button")
                    obj = (Button)sender;

                switch (obj.Name)
                {
                    case "btnChMais":
                        if (chIndex < (canal.Length - 1)) chIndex += 1;
                        else chIndex = 0;
                        break;

                    case "btnChMenos":
                        if (chIndex >= 1) chIndex -= 1;
                        else chIndex = (canal.Length - 1);
                        break;

                    case "chListView":
                        chIndex = (chListView.SelectedItems[0].Index);
                        break;

                    default:
                        break;
                }
                exibirCanal(canal[chIndex]);
            }
        }

        /// <summary>
        /// Chamado pelo bot�o para listar os canais
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listarCanais (object sender, EventArgs e)
        {
            alternaLista();
        }

        /// <summary>
        /// Alterna entre mostrar ou ocultar a lista de canais
        /// </summary>
        private void alternaLista()
        {
            if (ligado)
            {
                chListView.Items.Clear();

                if (listaOn)
                    chListView.SendToBack();
                else
                {
                    chListView.BringToFront();
                    carregaLista();
                }

                listaOn = !listaOn;
            }
        }

        /// <summary>
        /// Carrega a lista de canais
        /// </summary>
        private void carregaLista()
        {
            for (int i = 0; i < canal.Length; i++)
            {
                if (canal.ElementAt(i) != null)
                {
                    ListViewItem item = new ListViewItem((i + 1).ToString("000"));
                    item.SubItems.Add(canal.ElementAt(i));
                    chListView.Items.Add(item);
                }

                //int i = 1;
                //foreach (var link in canal)
                //{
                //    ListViewItem item = new ListViewItem(i.ToString("000"));
                //    item.SubItems.Add(link);
                //    chListView.Items.Add(item);
                //    i++;
                //}
            }
        }

        /// <summary>
        ///Metodo chamado no double-click sobre um item na lista de canais 
        /// </summary>
        private void chListView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            chMudar(sender, e);
        }

        //exibe uma tela sobre o desenvolvimento da aplica��o
        private void btnSobre_Click(object sender, EventArgs e)
        {
            SobreForm janelaSobre = new SobreForm();
            janelaSobre.ShowDialog();
        }

        /// <summary>
        /// Usado para aumentar, abaixar, ou mutar o volume
        /// </summary>
        private void volumeHandler(object sender, EventArgs e)
        {
            if (ligado)
            {
                Button clicado = (Button)sender;
                                
                if (clicado == btnMute)
                {
                    axVLC.audio.toggleMute();
                    muteVisualChange();
                }
                else
                {
                    if (axVLC.audio.mute) axVLC.audio.toggleMute();
                    
                    if (clicado == btnVolMais && axVLC.volume < 100)
                        axVLC.volume += 10;
                    else if (clicado == btnVolMenos && axVLC.volume > 0)
                        axVLC.volume -= 10;

                    muteVisualChange();
                }
            }
        }

        /// <summary>
        /// Troca o visual do bot�o de MUTE e label de volume
        /// </summary>
        private void muteVisualChange()
        {
            if (axVLC.audio.mute)
            {
                btnMute.Image = Properties.Resources.sound;
                btnMute.ForeColor = Color.GreenYellow;
                lblVol.Text = "MUTE";
                lblVol.ForeColor = Color.Red;
            }
            else
            {
                btnMute.Image = Properties.Resources.mute1;
                btnMute.ForeColor = Color.White;
                lblVol.Text = axVLC.volume.ToString();
                lblVol.ForeColor = Color.Black;
            }
        }

    }
}
