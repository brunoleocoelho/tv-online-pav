using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using ShockwaveFlashObjects;
using System.Diagnostics;

namespace TvOnline  
{
    public partial class Form1 : Form
    {
        List<Canal> listaCh;

        string [,]canal;
        int chAtual;
        bool ligado;
        bool listaOn;
        
        public Form1()
        {
            InitializeComponent();
            this.Icon = TvOnline.Properties.Resources.RetroTv;

            ligado = false;                         //controla se Tv lidada / desligada
            chAtual = 1;                            //numero do canal atual inicial (n�o o �ndice de array ou lista)
            listaOn = false;                        //controla exibi��o da lista de canais
            chListView.SendToBack();                //lista de canais na tela
            lblCh.SendToBack();                     //label do canal na tela
            lblVol.Text = axVLC.volume.ToString();  //label que exibe o volume do audio
            
            listaCh = new List<Canal>();
            
        }


        /// <summary>
        /// Liga ou desliga a TV
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ligarDesligar(object sender, EventArgs e)
        {
            if (!ligado)
            {
                simular_LerBD();
                btnPower.Text = "Desl";
                exibirCanal(listaCh[-1 + chAtual]);
                toolTip1.SetToolTip(TVpic, "Clique duplo sobre a tela para FULLSCREEN");
            }
            else
            {
                btnPower.Text = "Liga";
                rotularCanal("", "Deligado!");
                picLogo.Image = TvOnline.Properties.Resources.RetroTvPNG;
                listaOn = false;
                axVLC.playlist.stop();
                TVpic.BringToFront();
            }
            ligado = !ligado;
        }


        /// <summary>
        /// Simulando a leitura de um banco do dados
        /// canais num array provis�rio simulando BD
        /// Oficial usar BD SQLite e classe Canal
        /// </summary>
        private void simular_LerBD()
        {
            canal = new string[10, 5]; //simulando 10 canais diferentes
            //numerando os canais
            for (int i = 0; i < canal.GetLength(0); i++)
            {
                canal[i, 0] = (1 + i).ToString();
            }
            canal[0, 1] = "SBT HD";
            canal[0, 2] = "http://gbbrlive2.sambatech.com.br/liveevent/sbtabr_8fcdc5f0f8df8d4de56b22a2c6660470/livestream1/chunklist.m3u8"; //SBT HD
            canal[0, 3] = "https://listaiptvbrasil.com/logo/sbt.png";
            canal[0, 4] = "TV ABERTA";

            canal[1, 1] = "GLOBO SP";
            canal[1, 2] = "http://158.58.172.5:8081/look/sptv81/playlist.m3u8"; //GLOBO SP
            canal[1, 3] = "https://listaiptvbrasil.com/logo/globo.png";
            canal[1, 4] = "TV ABERTA";

            canal[2, 1] = "TV Cultura";
            canal[2, 2] = "http://200.189.113.201/hls/tve.m3u8"; //TV CULTURA
            canal[2, 3] = "http://tvcultura.com.br/_img/tvcultura/icones/logo.png";
            canal[2, 4] = "TV ABERTA";

            canal[3, 1] = "BAND";
            canal[3, 2] = "http://158.58.172.5:8081/look/band8/playlist.m3u8"; //BAND
            canal[3, 3] = "https://listaiptvbrasil.com/logo/band.png";
            canal[3, 4] = "TV ABERTA";

            canal[4, 1] = "SESC TV";
            canal[4, 2] = "http://api.new.livestream.com/accounts/16991778/events/6670101/live.m3u8"; //SESC TV
            //canal[4, 3] = "https://lut.im/AJ7bxR6dq6/B041Wsxo9yZayY64.png";
            canal[4, 4] = "TV ABERTA";

            canal[5, 1] = "FOX SPORTS";
            canal[5, 2] = "http://158.58.172.5:8081/look/foxsports10/playlist.m3u8"; //FOX SPORTS
            canal[5, 3] = "https://listaiptvbrasil.com/logo/foxsports.png";
            canal[5, 4] = "ESPORTES";

            canal[6, 1] = "RETRO CARTOON";
            canal[6, 2] = "http://stmv2.srvstm.com/cartoonr/cartoonr/playlist.m3u8"; //RETRO CARTOON
            canal[6, 3] = "https://lut.im/sh1ip2DP5J/8jScIxZVtuPkIwxY.JPG";
            canal[6, 4] = "KIDS";

            canal[7, 1] = "FOX NEWS";
            canal[7, 2] = "http://cmghlslive-i.akamaihd.net:80/hls/live/224710/WFOX/904k/prog.m3u8"; //FOX NEWS
            canal[7, 3] = "https://upload.wikimedia.org/wikipedia/commons/d/d4/Fox_News_Channel_logo.png";
            canal[7, 4] = "NOTICIAS";

            canal[8, 1] = "HEART TV";
            canal[8, 2] = "http://ooyalahd2-f.akamaihd.net/i/globalradio02_delivery@156522/master.m3u8";
            canal[8, 3] = "http://cdn-radiotime-logos.tunein.com/s221196q.png";
            canal[8, 4] = "MUSICAS";

            listaCh.Clear();
            //colocando os canais na lista da TV
            for (int i = 0; i < canal.GetLength(0); i++)
            {
                Canal ch = new Canal(
                    int.Parse(canal[i, 0]),
                    canal[i, 1],
                    canal[i, 2]
                );
                ch.LogoUrl = canal[i, 3];
                ch.Grupo = canal[i, 4];

                listaCh.Add(ch);
            }
        }


        /// <summary>
        /// Metodo da classe sobrescrito para fechar toda a aplica��o
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            this.Dispose();
            Application.Exit();
        }


        /// <summary>
        /// Exibe e carrega o canal atrav�s do link, trazendo pra frente no layout
        /// </summary>
        /// <param name="channel">O canal que ser� carregado</param>
        private void exibirCanal (Canal channel)
        {
            axVLC.playlist.stop();
            try
            {
                listaOn = false;
                string absUri = new Uri(channel.TvUrl).AbsoluteUri.ToString();
                if (!string.IsNullOrEmpty(absUri))
                {
                    axVLC.playlist.items.clear();
                    axVLC.playlist.add(absUri);
                    axVLC.playlist.play();
                    axVLC.BringToFront();
                }
                else
                {
                    picLogo.Image = TvOnline.Properties.Resources.RetroTvPNG;
                    chuviscoPic.BringToFront();
                }

                rotularCanal(channel);
                //(channel.Numero).ToString("000"), channel.Nome
            }
            catch (Exception ex)
            {
                chuviscoPic.BringToFront();
                picLogo.Image = TvOnline.Properties.Resources.RetroTvPNG;
                rotularCanal(ex.Message, "Fora do ar! :-(");
            }
        }


        /// <summary>
        /// Rotula a tela e a barra de titulo, se um canal for passado como parametro.
        /// </summary>
        /// <param name="channel">objeto Canal de onde s�o retiradas as informa��es de rotulagem</param>
        private void rotularCanal(Canal channel)
        {
            this.Text = Properties.Resources.AppName +" - Canal " + channel.Numero.ToString("000") + ": " + channel.Nome;
            lblCh.Text = "Canal " + channel.Numero.ToString("000") + ": "+ channel.Nome;

            if (!string.IsNullOrEmpty(channel.LogoUrl))
            {
                string picUri = new Uri(channel.LogoUrl).AbsoluteUri.ToString();
                picLogo.Load(picUri);
            }
            else
                picLogo.Image = TvOnline.Properties.Resources.RetroTvPNG;

            lblCh.BringToFront();
        }


        /// <summary>
        /// Rotula a tela e a barra de t�tulo com strings passadas como parametro.
        /// </summary>
        /// <param name="rotulo">Uma string contendo o texto a ser exibido na tela. Se vazio somente titulo preenchido</param>
        /// <param name="titulo">String contendo o texto a exibir na barra de titulo</param>
        private void rotularCanal(string rotulo, string titulo)
        {
            if (string.IsNullOrEmpty(rotulo))
            {
                this.Text = Properties.Resources.AppName + " - "+ titulo;
            }
            else
            {
                this.Text = Properties.Resources.AppName + " - Canal: "+ chAtual.ToString("000") +" "+ titulo;
                lblCh.Text = "Canal: "+ chAtual.ToString("000") +" - "+ rotulo;
                lblCh.BringToFront();
            }

        }


        /// <summary>
        /// Chamado pelo bot�o para mudar o canal em exibi��o
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chMudar(object sender, EventArgs e)
        {
            if (ligado) {

                //verificando primeiro o objeto origem da chamada
                var obj = new Control();
                if (sender.GetType().Name == "ListView")
                    obj = (ListView)sender;
                else if (sender.GetType().Name == "Button")
                    obj = (Button)sender;

                switch (obj.Name)
                {
                    case "btnChMais":
                        if (chAtual < listaCh.Count) chAtual += 1;
                        else chAtual = 1;
                        exibirCanal(listaCh.ElementAt<Canal>(-1 + chAtual)); //exibirCanal(listaCh[(-1+chAtual)]);
                        break;

                    case "btnChMenos":
                        if (chAtual > 1) chAtual -= 1;
                        else chAtual = listaCh.Count;
                        exibirCanal(listaCh.ElementAt<Canal>(-1+chAtual));
                        break;

                    case "chListView":
                        if (chAtual != (chListView.SelectedItems[0].Index + 1))
                        {
                            chAtual = (chListView.SelectedItems[0].Index + 1);
                            exibirCanal(listaCh.ElementAt<Canal>(-1 + chAtual)); //exibirCanal(listaCh[(-1+chAtual)]);
                        }
                        else
                        {
                            listarCanais(obj, e); //tira a lista de exibi��o
                        }
                        break;

                    default:
                        break;
                }
                
            }
        }


        /// <summary>
        /// Chamado pelo bot�o para listar os canais.
        /// Alterna entre mostrar ou ocultar a lista de canais
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listarCanais (object sender, EventArgs e)
        {
            if (ligado)
            {
                chListView.Items.Clear();

                if (listaOn)
                    chListView.SendToBack();
                else
                {
                    chListView.BringToFront();
                    carregaLista();
                }

                listaOn = !listaOn;
            }
        }


        /// <summary>
        /// Carrega a lista de canais
        /// </summary>
        private void carregaLista()
        {           
            foreach (var um in listaCh)
            {
                ListViewItem item = new ListViewItem(um.Numero.ToString("000"));
                item.SubItems.Add(um.Nome);
                item.SubItems.Add(um.Grupo);

                chListView.Items.Add(item);
            }
        }


        /// <summary>
        ///Metodo chamado no double-click sobre um item na lista de canais 
        /// </summary>
        private void chListView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            chMudar(sender, e);
        }


        //exibe uma tela sobre o desenvolvimento da aplica��o
        private void btnSobre_Click(object sender, EventArgs e)
        {
            SobreForm janelaSobre = new SobreForm();
            janelaSobre.ShowDialog();
        }


        /// <summary>
        /// Usado para aumentar, abaixar, ou mutar o volume
        /// </summary>
        private void volumeHandler(object sender, EventArgs e)
        {
            if (ligado)
            {
                Button clicado = (Button)sender;
                if (clicado == btnMute)
                {
                    axVLC.audio.toggleMute();
                    muteVisualChange();
                }
                else
                {
                    if (axVLC.audio.mute) axVLC.audio.toggleMute();
                    
                    if (clicado == btnVolMais && axVLC.volume < 100)
                        axVLC.volume += 10;
                    else if (clicado == btnVolMenos && axVLC.volume > 0)
                        axVLC.volume -= 10;

                    muteVisualChange();
                }
            }
        }

        
        /// <summary>
        /// Troca o visual do bot�o de MUTE e label de volume
        /// </summary>
        private void muteVisualChange()
        {
            if (axVLC.audio.mute)
            {
                btnMute.Image = Properties.Resources.sound;
                btnMute.ForeColor = Color.GreenYellow;
                lblVol.Text = "MUTE";
                lblVol.ForeColor = Color.Red;
            }
            else
            {
                btnMute.Image = Properties.Resources.mute;
                btnMute.ForeColor = Color.White;
                lblVol.Text = axVLC.volume.ToString();
                lblVol.ForeColor = Color.Black;
            }
        }

    }
}
