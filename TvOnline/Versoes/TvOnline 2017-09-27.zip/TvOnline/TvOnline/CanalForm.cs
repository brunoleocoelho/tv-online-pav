﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TvOnline.Modelo;

namespace TvOnline
{
    public partial class CanalForm : Form
    {
        Canal ch = new Canal();

        public CanalForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Define que ação será tomada em vários sentidos dentro do Form
        /// </summary>
        /// <param name="action"></param>
        /// <returns></returns>
        public bool setAction(string action, Canal c)
        {

            lblAction.Text = action + " Canal";

            if(action == "Novo")
            {
                this.Text = "Inserindo Novo Canal";
                btnExcluir.Visible = false;
                btnCancelar.Click += sairCanalForm;
                btnSalvar.Click += salvar_Click;
                return true;
            }
            else if (action == "Visualizar")
            {
                this.Text = "Visualizando Dados do Canal"; 
                preencheForm(c);
                bloqueioDeCampos();
                lblInfo.Visible = false;
                btnExcluir.Visible = false;
                btnCancelar.Click -= cancelaEditar_Click;
                btnCancelar.Click += sairCanalForm;
                btnSalvar.Text = "Editar";
                btnSalvar.Image = TvOnline.Properties.Resources.pencil_green;
                btnSalvar.Click -= salvar_Click;
                btnSalvar.Click += editar_Click;
                return true;
            }
            else if (action == "Editar")
            {
                this.Text = "Editando Dados do Canal";
                bloqueioDeCampos();
                btnExcluir.Visible = true;
                btnCancelar.Click -= sairCanalForm;
                btnCancelar.Click += cancelaEditar_Click;
                btnSalvar.Text = "Salvar";
                btnSalvar.Image = Properties.Resources.save_tick;
                btnSalvar.Click -= editar_Click;
                btnSalvar.Click += salvar_Click;
                return true;
            }
            else
            { //caso não consiga definir a ação, exibe uma mensagem
                this.Dispose();
                MessageBox.Show("Houve algum problema ao abrir a janela.", "Erro");
                return false;
            }
        }



        /// <summary>
        /// Referente ao botão de editar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void editar_Click(object sender, EventArgs e)
        {
            //guardando todos os campos num objeto
            if (string.IsNullOrEmpty(txtNumero.Text)) ch.Numero = 0;
            else ch.Numero = int.Parse(txtNumero.Text);
            ch.Nome = txtNome.Text.Trim();
            ch.TvUrl = txtTvUrl.Text.Trim();
            ch.LogoUrl = txtLogoUrl.Text.Trim();
            ch.Grupo = txtGrupo.Text.Trim();
            ch.Pais = txtPais.Text.Trim();
            ch.ParentControl = chkBoxParent.Checked;
            ch.ParentSenha = txtSenha.Text.Trim();
            setAction("Editar", ch);
        }

        /// <summary>
        /// Usado quando o usuário cancela a ação de editar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cancelaEditar_Click(object sender, EventArgs e)
        {
            setAction("Visualizar", ch);
        }

        /// <summary>
        /// Referente ao botão de salvar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void salvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text.Trim() == "" || txtTvUrl.Text.Trim() == "")
            {
                MessageBox.Show("Campos marcados com * (asterisco) são obrigatórios!", "Campos obrigatórios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Canal c = new Canal();
                c.Nome = txtNome.Text.Trim();
                c.TvUrl = txtTvUrl.Text.Trim();
                c.LogoUrl = txtLogoUrl.Text.Trim();
                c.Grupo = txtGrupo.Text.Trim();
                c.Pais = txtPais.Text.Trim();
                c.ParentControl = chkBoxParent.Checked;
                c.ParentSenha = txtSenha.Text.Trim();

                MessageBox.Show("Canal "+ c.Nome +" inserido!", "Mensagem", MessageBoxButtons.OK,MessageBoxIcon.Information);
                setAction("Visualizar", c);
            }

        }

        /// <summary>
        /// Usado na exclusão de um item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exclui_Click(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// Simplesmente sai da janela
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void sairCanalForm(object sender, EventArgs e)
        {
            this.Dispose();
        }

        /// <summary>
        /// Habilita / desabilita o "txtSenha" pelo "chkBoxParent"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkBoxParent_CheckedChanged(object sender, EventArgs e)
        {
            txtSenha.Enabled = !txtSenha.Enabled;
        }

        /// <summary>
        /// Preenche os campos na tela
        /// </summary>
        /// <param name="c"></param>
        private void preencheForm(Canal c)
        {
            //preenchendo campos na tela
            txtNome.Text = c.Nome;
            txtTvUrl.Text = c.TvUrl;
            txtLogoUrl.Text = c.LogoUrl;
            txtGrupo.Text = c.Grupo;
            txtPais.Text = c.Pais;
            chkBoxParent.Checked = c.ParentControl;
            txtSenha.Text = c.ParentSenha;
        }

        /// <summary>
        /// Bloqueia / desbloqueia vários campos do formulário para edição.
        /// </summary>
        private void bloqueioDeCampos()
        {
            txtNome.Enabled = !txtNome.Enabled;
            txtTvUrl.Enabled = !txtTvUrl.Enabled;
            txtLogoUrl.Enabled = !txtLogoUrl.Enabled;
            txtGrupo.Enabled = !txtGrupo.Enabled;
            txtPais.Enabled = !txtPais.Enabled;
            chkBoxParent.Enabled = !chkBoxParent.Enabled;
            //txtSenha.Enabled = !txtSenha.Enabled ;
        }

        /// <summary>
        /// Limpa os campos ao ao cancelar durante acão de inserir novo registro
        /// </summary>
        private void limpaCampos()
        {
            txtNome.Text = "";
            txtTvUrl.Text = "";
            txtLogoUrl.Text = "";
            txtGrupo.Text = "";
            txtPais.Text = "";
            chkBoxParent.Checked = false;
            txtSenha.Text = "";
            txtSenha.Enabled = false;
        }

    }
}
