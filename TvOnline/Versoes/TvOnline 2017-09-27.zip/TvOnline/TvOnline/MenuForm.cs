﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TvOnline.Modelo;

namespace TvOnline
{
    public partial class MenuForm : Form
    {
        List<Canal> listaDeCanais = new List<Canal>();
        string [,]canal;

        public MenuForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Usado para preenchimento da lista de canais
        /// </summary>
        /// <param name="ch"></param>
        public void PreencheLista(List<Canal> ch)
        {
            foreach (var um in ch)
            {
                ListViewItem item = new ListViewItem(um.Numero.ToString("000"));
                item.Tag = um;
                item.SubItems.Add(um.Nome);
                item.SubItems.Add(um.Grupo);
                listViewMenu.Items.Add(item);
            }
        }

        public void AddCanal(Canal c)
        {
            //se já existe, sbstirui pelo mais novo
            if ( c == listaDeCanais.ElementAt(listaDeCanais.IndexOf(c)))
            {
                //listaDeCanais.ElementAt(listaDeCanais.IndexOf(c));
                listaDeCanais.RemoveAt(listaDeCanais.IndexOf(c));
                listaDeCanais.Add(c);
            }
            //se não existe adiciona
            else
	        {
                listaDeCanais.Add(c);
                ListViewItem item = new ListViewItem(c.Numero.ToString("000"));
                item.Tag = c;
                item.SubItems.Add(c.Nome);
                item.SubItems.Add(c.Grupo);
                listViewMenu.Items.Add(item);
            }
        }

        public void RemoveCanal(Canal c)
        {
            if (c == listaDeCanais.ElementAt(listaDeCanais.IndexOf(c)))
            {
                listaDeCanais.RemoveAt(listaDeCanais.IndexOf(c));
            }
        }


        private void novo_Click(object sender, EventArgs e)
        {
            CanalForm formNovo = new CanalForm();
            Canal c = new Canal();
            if (formNovo.setAction("Novo", c))
                formNovo.ShowDialog();
        }

        private void visualizar_Click(object sender, EventArgs e)
        {
            ListView lista = (ListView)sender;
            Canal c = (Canal)lista.SelectedItems[0].Tag;
            CanalForm formVisualizar = new CanalForm();
            if (formVisualizar.setAction("Visualizar", c))
                formVisualizar.ShowDialog();
        }

        private void listViewMenu_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            visualizar_Click(sender, e);
        }


    }
}

