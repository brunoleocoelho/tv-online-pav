﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TvOnline.Modelo
{
    /// <summary>
    /// Classe para os canais a serem armazenados e exibidos
    /// </summary>
    public class Canal
    {
        //proriedades private da classe
        private int _numero;
        private string _nome;
        private string _tvUrl;
        private string _logoUrl;
        private string _grupo;
        private string _pais;
        private bool _parentControl;
        private string _parentSenha;
        

        //Construtores
        public Canal()
        {

        }

        public Canal(int numb, string name, string link)
        {
            this.Numero = numb;
            this.Nome = name;
            this.TvUrl = link;
        }


        //propriedades public
        public int Numero
        {
            get { return _numero; }
            set { _numero = value; }
        } 

        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public string TvUrl
        {
            get { return _tvUrl; }
            set { _tvUrl = value; }
        }

        public string LogoUrl
        {
            get { return _logoUrl; }
            set { _logoUrl = value; }
        }

        public string Grupo
        {
            get { return _grupo; }
            set { _grupo = value; }
        }

        public string Pais
        {
            get { return _pais; }
            set { _pais = value; }
        }

        public bool ParentControl
        {
            get { return _parentControl; }
            set { _parentControl = value; }
        }

        public string ParentSenha
        {
            get { return _parentSenha; }
            set { _parentSenha = value; }
        }
    }
}
